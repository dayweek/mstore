?package(mstore):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="mstore" command="/usr/bin/mstore"
