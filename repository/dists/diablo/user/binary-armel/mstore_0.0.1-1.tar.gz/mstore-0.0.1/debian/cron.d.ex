#
# Regular cron jobs for the mstore package
#
0 4	* * *	root	mstore_maintenance
